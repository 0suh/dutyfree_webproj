/* �ۼ��� : ������
 * ���α׷� ��� : VO ����*/
package com.dutyfree.dto;

public class ProductVO {
	private String product_id; //primary key
	private String prodgroup; //��ǰ����, ī�װ���
	private int price;
	private String img;
	private String best_product;
	private String pname;
	private String product_detail;
	private String product_explain;//��ǰ ����
	
	public String getProduct_explain() {
		return product_explain;
	}
	public void setProduct_explain(String product_explain) {
		this.product_explain = product_explain;
	}
	public String getProduct_detail() {
		return product_detail;
	}
	public void setProduct_detail(String product_detail) {
		this.product_detail = product_detail;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public String getProdgroup() {
		return prodgroup;
	}
	public void setProdgroup(String prodgroup) {
		this.prodgroup = prodgroup;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getImg() {
		return img;
	}
	public String getBest_product() {
		return best_product;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public void setBest_product(String best_product) {
		this.best_product = best_product;
	}
	
	
	
	
}
