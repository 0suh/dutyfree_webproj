package com.dutyfree.dto;

import java.sql.Timestamp;

public class OrderVO {
	private int ordernum;
	private String orderuserid;
	private Timestamp orderdate;
	
	
	public int getOrdernum() {
		return ordernum;
	}
	public void setOrdernum(int ordernum) {
		this.ordernum = ordernum;
	}
	public String getOrderuserid() {
		return orderuserid;
	}
	public void setOrderuserid(String orderuserid) {
		this.orderuserid = orderuserid;
	}
	public Timestamp getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Timestamp orderdate) {
		this.orderdate = orderdate;
	}
	
	
}
