package com.dutyfree.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.dutyfree.dto.CustomerVO;
import util.DBManager;

public class CustomerDAO {
		private CustomerDAO() { }
	private static CustomerDAO instance = new CustomerDAO();
	public static CustomerDAO getInstance() {
		return instance;
	}
	
	//ȸ�����Խ� DB�� insert
	public int insertCustomer(CustomerVO customerVO) {
		int result=0;
		//insert ���ν��� ��� (CallableStatement)
		String sql="{call PKG_DUTYFREE_PROJ.sp_customer_insert(?, ?, ?, ?, ?, ?, TO_DATE(?,'YYYY-MM-DD'), TO_DATE(?,'YYYY-MM-DD'))}";
		//���ν��� ��� ���ϴ� ��� (PreparedStatement)
		//String sql = "insert into customer(id, pw, name, email, addr, telnum, birth, joindate)"
		//		+ "	values(?, ?, ?, ?, ?, ?,  TO_DATE(?,'YYYY-MM-DD'), TO_DATE(?,'YYYY-MM-DD')) ";
		Connection conn=null;
		//PreparedStatement pstmt=null;
		CallableStatement cstmt = null;
		try {
			//insert ���ν��� ��� (CallableStatement)
			conn = DBManager.getConnection();
			cstmt = conn.prepareCall(sql);
			cstmt.setString(1, customerVO.getId());
			cstmt.setString(2, customerVO.getPw());
			cstmt.setString(3, customerVO.getName());
			cstmt.setString(4, customerVO.getEmail());
			cstmt.setString(5, customerVO.getAddr());
			cstmt.setString(6, customerVO.getTelnum());
			cstmt.setString(7, customerVO.getBirth());
			cstmt.setString(8, customerVO.getJoindate());
			cstmt.executeQuery();
			//���ν��� ��� ���ϴ� ���
//			conn = DBManager.getConnection();
//			pstmt = conn.prepareStatement(sql);
//			pstmt.setString(1, customerVO.getId());
//			pstmt.setString(2, customerVO.getPw());
//			pstmt.setString(3, customerVO.getName());
//			pstmt.setString(4, customerVO.getEmail());
//			pstmt.setString(5, customerVO.getAddr());
//			pstmt.setString(6, customerVO.getTelnum());
//			pstmt.setString(7, customerVO.getBirth());
//			pstmt.setString(8, customerVO.getJoindate());
//			result = pstmt.executeUpdate();
		}catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		    	DBManager.close(conn, cstmt);
		      //DBManager.close(conn, pstmt);
		    }
		return result;
	}
	
	//���� ���� �ҷ�����
	public CustomerVO getCustomer(String id) {
		CustomerVO  customerVO = null;
		//sf_get_customer_info �Լ� ���
		String sql="select * from TABLE(PKG_DUTYFREE_PROJ.sf_get_customer_info(?))";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				//���� ���� ��������
				customerVO = new CustomerVO();
				customerVO.setId(rs.getString("id"));
				customerVO.setPw(rs.getString("pw"));
				customerVO.setName(rs.getString("name"));
				customerVO.setEmail(rs.getString("email"));
				customerVO.setAddr(rs.getString("addr"));
				customerVO.setTelnum(rs.getString("telnum"));
				customerVO.setBirth(rs.getString("birth"));
				customerVO.setJoindate(rs.getString("joindate"));
				}
			}catch (Exception e) {
			      e.printStackTrace();
		    } finally {
		      DBManager.close(conn, pstmt, rs);
		    }
		    return customerVO; //���� ����
		}
	
	//���� ���� ������Ʈ
	public int updateCustomer(CustomerVO customerVO) {
		int result=0;
		//update ���ν��� ��� (CallableStatement)
		String sql="{call PKG_DUTYFREE_PROJ.sp_customer_update(?, ?, ?, ?, ?, ?)}";
		Connection conn=null;
		CallableStatement cstmt = null;
		try {
			//update ���ν��� ��� (CallableStatement)
			conn = DBManager.getConnection();
			cstmt = conn.prepareCall(sql);
			cstmt.setString(1, customerVO.getId());
			cstmt.setString(2, customerVO.getPw());
			cstmt.setString(3, customerVO.getName());
			cstmt.setString(4, customerVO.getEmail());
			cstmt.setString(5, customerVO.getAddr());
			cstmt.setString(6, customerVO.getTelnum());
	
			cstmt.executeQuery();
		}catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		    	DBManager.close(conn, cstmt);
		    }
		return result;
	}
	
	//���� Ż��
	public int deleteCustomer(String id) {
		int result=0;
		//sp_customer_delete �Լ� ȣ��
		String sql="{call PKG_DUTYFREE_PROJ.sp_customer_delete(?)}";
		Connection conn=null;
		CallableStatement cstmt = null;
		try {
			//update ���ν��� ��� (CallableStatement)
			conn = DBManager.getConnection();
			cstmt = conn.prepareCall(sql);
			cstmt.setString(1, id);
			cstmt.executeQuery();
		}catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		    	DBManager.close(conn, cstmt);
		    }
		return result;
	}
	//���̵� �ߺ� Ȯ��
	public int checkCustomer(String id) {
		int result=-1;
		//sf_customer_id_exist �Լ� ȣ��
		//�÷���: cnt
		String sql="select PKG_DUTYFREE_PROJ.sf_customer_id_exist(?) as cnt from dual";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				//���� ���̵��� ���������� 0�� �ƴϸ�
				if(rs.getInt("cnt")!=0) {
					result=1; //���̵� �����ϴ� ��� ȸ������ �Ұ�
					System.out.println("���̵� ���� - ȸ������ �Ұ�");
					//System.out.println(result);
				}
				//���̵� ���������� ������
				else {
					result=0; //���̵� �������� �ʴ� ��� ȸ������ ����
					System.out.println("ȸ������ ����");
					//System.out.println(result);
				}
			}
		}catch (Exception e) {
			      e.printStackTrace();
			      } finally {
			    	DBManager.close(conn, pstmt);
			    }
			return result;
			
	}
	
}

