//�ۼ��� : ����ä
//��� : BoardDao�� implements�Ͽ� ������ ���̽� ���� ó���� ���ش�.
package com.dutyfree.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.CallableStatement;

import com.dutyfree.dto.BoardVO;

import util.DBManager;

public class BoardDaoImpl implements BoardDao {
	
	// �Խñ� �ۼ� - PL/SQL ���ν��� ���
	@Override
	public void writePost(BoardVO boardVO) {
		String insertPost = "{call PKG_DUTYFREE_PROJ.sp_board_insert(?, ?, ?, TO_DATE(?,'YYYY-MM-DD'), sequence_board.NEXTVAL)}";
		Connection conn = null;
		CallableStatement cstmt = null;
		try {
			conn = DBManager.getConnection();
			cstmt = conn.prepareCall(insertPost);
			cstmt.setString(1, boardVO.getWriterid());
			cstmt.setString(2, boardVO.getTitle());
			cstmt.setString(3, boardVO.getQcontent());
			cstmt.setString(4, boardVO.getWritedate());
			cstmt.executeUpdate();
		} catch (Exception e) {
	      e.printStackTrace();
	    } finally {
	    	DBManager.close(conn, cstmt);
	    }
	}

//	�Խñ� �ۼ� - ���ν��� ��� ������ ���
//	@Override
//	public void writePost(BoardVO boardVO) throws SQLException {
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		try {
//			conn = DBManager.getConnection();
//			StringBuilder insertPost = new StringBuilder();
//			insertPost.append("insert into board (writerid, title, qcontent, writedate, postno) \n");
//			insertPost.append("values (?, ?, ?, TO_DATE(?,'YYYY-MM-DD'), sequence_board.NEXTVAL)");
//			pstmt = conn.prepareStatement(insertPost.toString());
//			pstmt.setString(1, boardVO.getWriterid());
//			pstmt.setString(2, boardVO.getTitle());
//			pstmt.setString(3, boardVO.getQcontent());
//			pstmt.setString(4, boardVO.getWritedate());
//			pstmt.executeUpdate();
//		} finally {
//			DBManager.close(conn, pstmt);
//		}
//	}

	// �Խñ� ��ü ��� (Ű���� �˻� ��� ����)
	@Override
	public List<BoardVO> listPost(String key, String word) throws SQLException {
		List<BoardVO> list = new ArrayList<BoardVO>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBManager.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select postno, writerid, title, qcontent, writedate \n");
			sql.append("from board \n");
			if(!word.isEmpty()) {
				if("title".equals(key)) {
					sql.append("where title like ? \n");
				} else {
					sql.append("where " + key + " = ? \n");
				}
			}
			sql.append("order by postno desc \n"); // ��������. �ֽű� ������ ������������ ���� ������
			pstmt = conn.prepareStatement(sql.toString());
			if(!word.isEmpty()) {
				if("title".equals(key))
					pstmt.setString(1, "%" + word + "%"); // �˻�� ���Ե� ��� ���� �޾ƿ� �� �ֵ��� %word%
				else
					pstmt.setString(1, word);
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BoardVO boardVO = new BoardVO();
				boardVO.setPostno(rs.getInt("postno"));
				boardVO.setWriterid(rs.getString("writerid"));
		    	boardVO.setTitle(rs.getString("title"));
		    	boardVO.setQcontent(rs.getString("qcontent"));
//		    	boardVO.setAcontent(rs.getString("acontent"));
		    	boardVO.setWritedate(rs.getString("writedate"));
//		    	boardVO.setHits(rs.getInt("hits"));
				list.add(boardVO);
			}
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		
		return list;
	}
	
	
	
	// �Խñ� �ϳ� �� ���� - PL/SQL �Լ� ��� (recode ����, table ��ü ����, �Լ� ����)
	@Override
	public BoardVO getPost(int postno) {
		BoardVO boardVO = null;
		String sql = "select * from TABLE(PKG_DUTYFREE_PROJ.sf_board_post_detail(?))";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, postno);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				boardVO = new BoardVO();
				boardVO.setPostno(rs.getInt("postno"));
				boardVO.setWriterid(rs.getString("writerid"));
		    	boardVO.setTitle(rs.getString("title"));
		    	boardVO.setQcontent(rs.getString("qcontent"));
//		    	boardVO.setAcontent(rs.getString("acontent"));
		    	boardVO.setWritedate(rs.getString("writedate"));
//		    	boardVO.setHits(rs.getInt("hits"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return boardVO;
	}

//	�Խñ� �ϳ� �� ���� - �Լ� ��� ������ ���
//	@Override
//	public BoardVO getPost(int postno) throws SQLException {
//		BoardVO boardVO = null;
//		
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		
//		try {
//			conn = DBManager.getConnection();
//			StringBuilder sql = new StringBuilder();
//			sql.append("select postno, writerid, title, qcontent, writedate \n");
//			sql.append("from board \n");
//			sql.append("where postno = ?");
//			pstmt = conn.prepareStatement(sql.toString());
//			pstmt.setInt(1, postno);
//			rs = pstmt.executeQuery();
//			if(rs.next()) {
//				boardVO = new BoardVO();
//				boardVO.setPostno(rs.getInt("postno"));
//				boardVO.setWriterid(rs.getString("writerid"));
//		    	boardVO.setTitle(rs.getString("title"));
//		    	boardVO.setQcontent(rs.getString("qcontent"));
////		    	boardVO.setAcontent(rs.getString("acontent"));
//		    	boardVO.setWritedate(rs.getString("writedate"));
////		    	boardVO.setHits(rs.getInt("hits"));
//			}
//		} finally {
//			DBManager.close(conn, pstmt, rs);
//		}
//		return boardVO;
//	}

	// �Խñ� ���� - PL/SQL ���ν��� ���
	@Override
	public void modifyPost(BoardVO boardVO){
		String modify = "{call PKG_DUTYFREE_PROJ.sp_board_update(?, ?, ?)}";
		Connection conn = null;
		CallableStatement cstmt = null;
		try {
			conn = DBManager.getConnection();
			cstmt = conn.prepareCall(modify);
			cstmt.setInt(1, boardVO.getPostno());
			cstmt.setString(2, boardVO.getTitle());
			cstmt.setString(3, boardVO.getQcontent());
			cstmt.executeUpdate();
		} catch (Exception e) {
	      e.printStackTrace();
	    } finally {
	    	DBManager.close(conn, cstmt);
	    }
	}
	
//	�Խñ� ���� - ���ν��� ��� ������ ���
//	@Override
//	public void modifyPost(BoardVO boardVO) throws SQLException {
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		try {
//			conn = DBManager.getConnection();
//			StringBuilder modify = new StringBuilder();
//			modify.append("update board \n");
//			modify.append("set title = ?, qcontent = ? \n");
//			modify.append("where postno = ?");
//			pstmt = conn.prepareStatement(modify.toString());
//			pstmt.setString(1, boardVO.getTitle());
//			pstmt.setString(2, boardVO.getQcontent());
//			pstmt.setInt(3, boardVO.getPostno());
//			pstmt.executeUpdate();
//		} finally {
//			DBManager.close(conn, pstmt);
//		}
//
//	}

	// �Խñ� ���� - PL/SQL ���ν��� ���
	@Override
	public void deletePost(int postno){
		String deletePost = "{call PKG_DUTYFREE_PROJ.sp_board_delete(?)}";
		Connection conn = null;
		CallableStatement cstmt = null;
		try {
			conn = DBManager.getConnection();
			cstmt = conn.prepareCall(deletePost);
			cstmt.setInt(1, postno);
			cstmt.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, cstmt);
		}
	}


//	�Խñ� ���� - ���ν��� ��� ������ ���
//	@Override
//	public void deletePost(int postno) throws SQLException {
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		try {
//			conn = DBManager.getConnection();
//			StringBuilder deletePost = new StringBuilder();
//			deletePost.append("delete from board \n");
//			deletePost.append("where postno = ?");
//			pstmt = conn.prepareStatement(deletePost.toString());
//			pstmt.setInt(1, postno);
//			pstmt.executeUpdate();
//		} finally {
//			DBManager.close(conn, pstmt);
//		}
//
//	}

}
