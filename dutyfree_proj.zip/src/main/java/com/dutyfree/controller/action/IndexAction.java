//�ۼ���: ������
//���: index.jsp(����������)�� �̵�
package com.dutyfree.controller.action;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.dutyfree.dao.ProductDAO;
import com.dutyfree.dto.ProductVO;

public class IndexAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/index.jsp";
		
		/*������ ����*/
		ProductDAO productDAO = ProductDAO.getInstance();
		ArrayList<ProductVO> ProductList = productDAO.listProduct(); // ��� ��ǰ list ������ֱ�
		
		request.setAttribute("ProductList", ProductList);
		
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
	    dispatcher.forward(request, response);
			
	}

}
